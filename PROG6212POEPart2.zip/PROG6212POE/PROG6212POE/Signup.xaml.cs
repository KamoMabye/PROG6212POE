﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;


namespace PROG6212POE
{
    /// <summary>
    /// Interaction logic for Signup.xaml
    /// </summary>
    public partial class Signup : Window
    {
        //This creates a connection with the MySql database
        private const string ConnectionString = "Server=localhost;Database=PROG6212POE;Uid=root;pwd=;";
        private MySqlConnection conn;

        public Signup()
        {
            InitializeComponent();
            conn = new MySqlConnection(ConnectionString);
        }

        private void signupButton_Click(object sender, RoutedEventArgs e)
        {

            using (conn)
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO users (username, password) VALUES (@Username, @PasswordHash)", conn);
                        cmd.Parameters.AddWithValue("@Username", userSignup.Text);
                        cmd.Parameters.AddWithValue("@PasswordHash", passSignup.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Sign Up Successful!");
                    conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
            }
        }

        private async void loginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = userLogin.Text;
            string password = passLogin.Text;

            // Simulate a login check with a delay
            bool isAuthenticated = await Task.Run(() => SimulateLogin(username, password));

            if (isAuthenticated)
            {

                int uid = GetUserIdByUsername(username);

                Dispatcher.Invoke(() => {
                    MainWindow mainWindow = new MainWindow(uid);
                    mainWindow.Show();
                    conn.Close();
                    Close(); // Close the login window
                });

            }
            else
            {
                MessageBox.Show("Login failed. Please check your username and password.");
            }
        }
        private int GetUserIdByUsername(string username)
        {
            using (conn)
            {
                conn.Open();
                string selectQuery = "SELECT UserID FROM users WHERE username = @Username";

                using (MySqlCommand command = new MySqlCommand(selectQuery, conn))
                {
                    command.Parameters.AddWithValue("@Username", username);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return reader.GetInt32(0);
                        }
                    }
                }
            }
            // Return -1 or throw an exception if the user is not found
            return -1;
        }

        private bool SimulateLogin(string username, string password)
        {
            // Simulate a delay for demonstration purposes
            Task.Delay(TimeSpan.FromSeconds(2)).Wait();
                using (conn)
                {
                    conn.Open();
                    using (MySqlCommand command = new MySqlCommand("SELECT password FROM users WHERE username = @Username", conn))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        string storedPassword = command.ExecuteScalar() as string;
                        if (storedPassword != null)
                        {
                        if (storedPassword.Equals(password))
                        {
                            MessageBox.Show("Log in Successful!");
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                        }
                    }
                }
                return false;
            }
    }
}
