﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using PROG6212POEClassLibrary;

namespace PROG6212POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string ConnectionString = "Server=localhost;Database=PROG6212POE;Uid=root;pwd=;";
        private MySqlConnection conn;
        private int userid;
        public MainWindow(int userid)
        {
            InitializeComponent();
            conn = new MySqlConnection(ConnectionString);
            this.userid = userid;

            using (conn)
            {
                conn.Open();

                // Create a SQL command to retrieve data
                using (MySqlCommand command = new MySqlCommand("SELECT moduleCode, moduleName, Credits, classHours, selfStudyHours FROM modules WHERE userID = @UserID", conn))
                {
                    command.Parameters.AddWithValue("@UserID", userid);
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Bind the data to the ListView
                        moduleListView.ItemsSource = dataTable.DefaultView;
                    }
                }
            }

            using (conn)
            {
                conn.Open();

                // Create a SQL command to retrieve data
                using (MySqlCommand command = new MySqlCommand("SELECT moduleName, selfStudyRemain FROM modules WHERE userID = @UserID", conn))
                {
                    command.Parameters.AddWithValue("@UserID", userid);
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Bind the data to the ListView
                        hoursLeft.ItemsSource = dataTable.DefaultView;
                    }
                }
            }

            using (conn)
            {
                conn.Open();

                // Create a SQL command to retrieve data
                using (MySqlCommand command = new MySqlCommand("SELECT moduleName, hoursWorked, dateWorked FROM hoursWorked", conn))
                {
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Bind the data to the ListView
                        specifyModView.ItemsSource = dataTable.DefaultView;
                    }
                }
            }

        }

        private void addModule_Click(object sender, RoutedEventArgs e)
        {

            //Checks if the textboxes have been filled in
            if (modCode.Text.Equals("") || modName.Text.Equals("") || numCred.Text.Equals("") || classHour.Text.Equals("") || weekSem.Text.Equals(""))
            {
                MessageBox.Show("Please make sure all boxes have been filled in!");
            }
            else
            {

                Calculation cal = new Calculation();
                //Puts all textbox values into variables
                string code = modCode.Text;
                string name = modName.Text;
                double credits = 0;
                double hoursPerWeek = 0;
                double semWeek = 0;
                try
                {
                    semWeek = double.Parse(weekSem.Text);
                    credits = double.Parse(numCred.Text);
                    hoursPerWeek = double.Parse(classHour.Text);
                }
                catch (FormatException o)
                {
                    MessageBox.Show("Please make sure numbers are input!!");
                    modCode.Clear();
                    modName.Clear();
                    numCred.Clear();
                    classHour.Clear();
                }

                double selfstudy = cal.selfHours(credits, semWeek, hoursPerWeek);//Calculation to get the self study hours

                Modules mod = new Modules();

                //Adding values to the modules class
                mod.moduleCode = code;
                mod.moduleName = name;
                mod.classHoursPerWeek = hoursPerWeek;
                mod.numOfCredits = credits;
                mod.selfStudy = selfstudy;
                double selfStudyRemain = cal.selfHoursRemain(mod.selfStudy);
                int userID = userid;

                using (conn)
                {
                    conn.Open();
                    string insertQuery = "INSERT INTO modules (userID, moduleCode, moduleName, Credits, classHours, selfStudyHours, selfStudyRemain) " +
                                          "VALUES (@UserID, @ModuleCode, @ModuleName, @Credits, @ClassHoursPerWeek, @SelfStudyHours, @SelfStudyRemain)";

                    using (MySqlCommand command = new MySqlCommand(insertQuery, conn))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        command.Parameters.AddWithValue("@ModuleCode", modCode.Text);
                        command.Parameters.AddWithValue("@ModuleName", modName.Text);
                        command.Parameters.AddWithValue("@Credits", int.Parse(numCred.Text));
                        command.Parameters.AddWithValue("@ClassHoursPerWeek", int.Parse(classHour.Text));
                        command.Parameters.AddWithValue("@SelfStudyHours", selfstudy);
                        command.Parameters.AddWithValue("@SelfStudyRemain", selfStudyRemain);

                        command.ExecuteNonQuery();
                    }
                }

                using (conn)
                {
                    conn.Open();

                    // Create a SQL command to retrieve data
                    using (MySqlCommand command = new MySqlCommand("SELECT moduleCode, moduleName, Credits, classHours, selfStudyHours FROM modules WHERE userID = @UserID", conn))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            // Bind the data to the ListView
                            moduleListView.ItemsSource = dataTable.DefaultView;
                        }
                    }
                }

                using (conn)
                {
                    conn.Open();

                    // Create a SQL command to retrieve data
                    using (MySqlCommand command = new MySqlCommand("SELECT moduleName, selfStudyRemain FROM modules WHERE userID = @UserID", conn))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            // Bind the data to the ListView
                            hoursLeft.ItemsSource = dataTable.DefaultView;
                        }
                    }
                }

                modCode.Clear();
                modName.Clear();
                numCred.Clear();
                classHour.Clear();
            }
        }

        private void semInfo_Click(object sender, RoutedEventArgs e)
        {
            //Displays start date and weeks in semester
            dateDisplay.Text = semDate.Text;
            weekDisplay.Text = weekSem.Text;
        }

        private void specifyHours_Click(object sender, RoutedEventArgs e)
        {
            string sModule = specifyMod.Text;
            int numHours = int.Parse(numOfHours.Text);
            int userID = userid;
            using (conn)
            {
                conn.Open();
                string insertQuery = "INSERT INTO hoursWorked (moduleName, hoursWorked, dateWorked) " +
                                      "VALUES (@ModuleName, @HoursWorked, @DateWorked)";

                using (MySqlCommand command = new MySqlCommand(insertQuery, conn))
                {
                    command.Parameters.AddWithValue("@ModuleName", sModule);
                    command.Parameters.AddWithValue("@HoursWorked", numHours);
                    command.Parameters.AddWithValue("@DateWorked", specificDay.Text);

                    command.ExecuteNonQuery();
                }
            }

            using (conn)
            {
                conn.Open();

                // Create a SQL command to retrieve data
                using (MySqlCommand command = new MySqlCommand("SELECT moduleName, hoursWorked, dateWorked FROM hoursWorked", conn))
                {
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Bind the data to the ListView
                        specifyModView.ItemsSource = dataTable.DefaultView;
                    }
                }
            }

            specifyMod.Clear();
            numOfHours.Clear();


        }

        private void logOut_Click(object sender, RoutedEventArgs e)
        {
            Signup signup = new Signup();
            signup.Show();
            conn.Close();
            Close();
        }
    }
}
