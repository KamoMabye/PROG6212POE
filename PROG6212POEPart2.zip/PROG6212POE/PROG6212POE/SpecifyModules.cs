﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG6212POE
{
    internal class SpecifyModules
    {
        public string modNames { get; set; }
        public DateOnly Date {get;set;}
        public int hours {get;set;}

    }
}
