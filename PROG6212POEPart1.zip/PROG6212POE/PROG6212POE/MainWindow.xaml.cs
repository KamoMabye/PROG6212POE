﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PROG6212POEClassLibrary;

namespace PROG6212POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Creating list of module class
        private List<Modules> moduless = new List<Modules> ();
        private List<SpecifyModules> specifyModules = new List<SpecifyModules> ();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void addModule_Click(object sender, RoutedEventArgs e)
        {
            
            //Checks if the textboxes have been filled in
            if (modCode.Text.Equals("") || modName.Text.Equals("") || numCred.Text.Equals("") || classHour.Text.Equals("") || weekSem.Text.Equals(""))
            {
                MessageBox.Show("Please make sure all boxes have been filled in!");
            }
            else
            {

                Calculation cal = new Calculation();
                //Puts all textbox values into variables
                string code = modCode.Text;
                string name = modName.Text;
                double credits = 0;
                double hoursPerWeek = 0;
                double semWeek = 0;
                try
                {
                    semWeek = double.Parse(weekSem.Text);
                    credits = double.Parse(numCred.Text);
                    hoursPerWeek = double.Parse(classHour.Text);
                }
                catch (FormatException o)
                {
                    MessageBox.Show("Please make sure numbers are input!!");
                    modCode.Clear();
                    modName.Clear();
                    numCred.Clear();
                    classHour.Clear();
                }

                double selfstudy = cal.selfHours(credits, semWeek, hoursPerWeek);//Calculation to get the self study hours

                Modules mod = new Modules();
                
                //Adding values to the modules class
                mod.moduleCode = code;
                mod.moduleName = name;
                mod.classHoursPerWeek = hoursPerWeek;
                mod.numOfCredits = credits;
                mod.selfStudy = selfstudy;
                mod.selfStudyRemain = cal.selfHoursRemain(mod.selfStudy);

                //Adding class to the list<>
                moduless.Add(mod);

                //LINQ to display modules that have self study hours above 0
                var selectedModules = moduless.Where(Modules => Modules.selfStudy > 0);

                modCode.Clear();
                modName.Clear();
                numCred.Clear();
                classHour.Clear();

                moduleListView.ItemsSource = null;
                moduleListView.ItemsSource = selectedModules;//Adds LINQ to ListView

                if (selfstudy <= 0)
                {

                }
                else
                {
                    hoursLeft.Items.Add(new { mod.moduleName, mod.selfStudyRemain });
                }
                

            }
        }

        private void semInfo_Click(object sender, RoutedEventArgs e)
        {
            //Displays start date and weeks in semester
            dateDisplay.Text = semDate.Text;
            weekDisplay.Text = weekSem.Text;
        }

        private void specifyHours_Click(object sender, RoutedEventArgs e)
        {
            string sModule = specifyMod.Text;
            DateOnly sDate = DateOnly.Parse(specificDay.Text);
            int numHours = int.Parse(numOfHours.Text);
            

            SpecifyModules mod = new SpecifyModules();

            mod.Date = sDate;
            mod.modNames = sModule;
            mod.hours = numHours;

            specifyModules.Add(mod);

            //LINQ to display modules, date and hours
            var selectedModules = specifyModules.Where(SpecifyModules => SpecifyModules.hours > 0);

            specifyMod.Clear();
            numOfHours.Clear();


            specifyModView.ItemsSource = null;
            specifyModView.ItemsSource = selectedModules;


        }
    }
}
